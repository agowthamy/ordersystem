
module.exports=
{
    host : "localhost",
    database : "ordersystem",
    user : "root",
    password : "root"
}